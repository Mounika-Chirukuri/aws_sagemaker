import json;
import time;
import urllib.request;
import boto3;

def lambda_handler(event, context):
    transcribe = boto3.client('transcribe')
    job_name = "transcibe-demo"
    job_uri = "https://amazon-transcribe-gmrit.s3.amazonaws.com/transcribe-sample.mp3"
    transcribe.start_transcription_job(
    TranscriptionJobName=job_name,
    Media={'MediaFileUri': job_uri},
    MediaFormat='mp3',
    LanguageCode='en-US')
    while True:
        status = transcribe.get_transcription_job(TranscriptionJobName=job_name)
        if status['TranscriptionJob']['TranscriptionJobStatus'] in ['COMPLETED', 'FAILED']:
            break
        time.sleep(2)
    if status['TranscriptionJob']['TranscriptionJobStatus'] == 'COMPLETED':
        response = urllib.request.urlopen(status['TranscriptionJob']['Transcript']['TranscriptFileUri'])
        data = json.loads(response.read())
        text = data['results']['transcripts'][0]['transcript']
        print(text)
    return {
        'statusCode': 200,
        'body': text
    }